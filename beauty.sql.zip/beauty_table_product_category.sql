
-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--
-- Creation: Jul 30, 2021 at 03:00 PM
--

DROP TABLE IF EXISTS `product_category`;
CREATE TABLE `product_category` (
  `p_cat_id` int(10) NOT NULL,
  `p_cat_title` text NOT NULL,
  `p_cat_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`p_cat_id`, `p_cat_title`, `p_cat_desc`) VALUES
(2, 'EYES', 'Eye makeup is a type of cosmetics which aims to make the eyes look noticeable and attractive. It is mostly used by females, and by stage performers of all types. Eye makeup is an important part of the fashion and cosmetic industries. Main products of Eye makeup are Mascara , Eye liner , Kajal etc..				'),
(3, 'FACE POWDERS', 'Face powder is a cosmetic product applied to the face to serve different functions, typically to beautify the face.One of which is loose powder, which is used to assist with oily skin in absorbing excess moisture and mattifying the face to reduce shininess.				'),
(4, 'SKINCARE', 'Skin care is the range of practices that support skin integrity, enhance its appearance and relieve skin conditions. They can include nutrition, avoidance of excessive sun exposure and appropriate use of emollients.Skin care is a part of the treatment of wound healing, radiation therapy and some medications						'),
(5, 'LIPS', 'Lips is an organ in which we can apply cosmetic that gives color, texture, and protection to the lips. Many colors and types of lipstick exist.						'),
(6, 'NAILS', 'A nail is a hard part of the body at the tip of the fingers and toes, of which most people have ten. Toenails and fingernails .We can decorate nails using nail polish etc..							');
