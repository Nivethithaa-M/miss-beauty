
-- --------------------------------------------------------

--
-- Table structure for table `categories`
--
-- Creation: Jul 30, 2021 at 03:03 PM
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `cat_id` int(10) NOT NULL,
  `cat_title` text NOT NULL,
  `cat_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`, `cat_desc`) VALUES
(2, 'ELLE', 'ELLE is the world\'s largest fashion magazine and media brand inspiring women to explore and celebrate style in all aspects of their lives with content that is inclusive and innovative.'),
(3, 'NYKAA', 'Nykaa is an India based brand that specialises in multi-beauty and personal care products. The brand had been originally established as a sole e-commerce medium until it later began setting up various retail outlets in many metropolitan cities across the nation. 						'),
(4, 'LAKME', 'Lakmé is an Indian cosmetics brand which is owned by Hindustan Unilever. Having Kareena Kapoor and Chamma as the ambassador, it ranked at number 1 among the cosmetics brands in India.					'),
(5, 'LOREAL PARIS', 'The Loreal Paris Brand Division of Loreal USA, Inc. is a total beauty care company that combines the latest in technology with the highest in quality for the ultimate in luxury beauty at mass. Loreal Paris is a truly global beauty brand with many internationally renowned products.				'),
(6, 'MAC', 'M·A·C is a proud COMMUNITY of professional makeup artists working together to bring our vision to life. M·A·C is at the forefront of fashion TRENDSETTING, collaborating with leading talents from fashion, art and popular culture. Our Artists create trends backstage at fashion weeks around the world.			'),
(7, 'MAYBELLINE', 'Maybelline New York is the number one global cosmetics brand and is available in over 129 countries worldwide. Offering more than 200 products, Maybelline New York combines technologically advanced formulas with on-trend expertise to create accessible cosmetics with a cool, urban edge and a spirited style.			'),
(8, 'NIVEA', 'NIVEA is a global skin - and body-care brand, owned by the German company Beiersdorf. The company was founded on March 28 1882 by pharmacist Carl Paul Beiersdorf. In 1900, the new owner Oskar Troplowitz developed a water-in-oil emulsifier as a skin cream with Eucerit, the first stable emulsion of its kind. 					'),
(9, 'PONDS', 'Ponds is an American brand of beauty and health care products, currently owned by parent company the multinational corporation Unilever.					');
