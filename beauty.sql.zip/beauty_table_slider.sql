
-- --------------------------------------------------------

--
-- Table structure for table `slider`
--
-- Creation: Jul 30, 2021 at 02:38 PM
--

DROP TABLE IF EXISTS `slider`;
CREATE TABLE `slider` (
  `id` int(10) NOT NULL,
  `slider_name` varchar(255) NOT NULL,
  `slider_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `slider_name`, `slider_image`) VALUES
(1, 'slider number 1', '1.jpg'),
(2, 'slider number 2', '2.jpg'),
(3, 'slider number 3', '3.jpg'),
(4, 'slider number 4', '4.jpg');
