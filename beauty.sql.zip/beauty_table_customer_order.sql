
-- --------------------------------------------------------

--
-- Table structure for table `customer_order`
--
-- Creation: Aug 01, 2021 at 03:36 AM
--

DROP TABLE IF EXISTS `customer_order`;
CREATE TABLE `customer_order` (
  `order_id` int(10) NOT NULL,
  `product_id` int(100) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `due_amount` int(100) NOT NULL,
  `invoice_no` int(100) NOT NULL,
  `qty` int(10) NOT NULL,
  `size` text NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `order_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer_order`
--

INSERT INTO `customer_order` (`order_id`, `product_id`, `customer_id`, `due_amount`, `invoice_no`, `qty`, `size`, `order_date`, `order_status`) VALUES
(3, 2, 1, 1800, 828511470, 4, '250g', '2021-08-01 03:37:20', 'pending');
